// flags for shmget
#define IPC_CREAT 01000
#define IPC_EXCL 02000
#define IPC_PRIVATE 0

// flags for shmctl
#define IPC_RMID 0
#define IPC_SET 1
#define IPC_STAT 2